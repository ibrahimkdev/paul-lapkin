import Swiper from './swiper.svelte';
import SwiperSlide from './swiper-slide.svelte';

export { Swiper, SwiperSlide };
